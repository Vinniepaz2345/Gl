const buildMenu = require('../lib/menuBuilder');

module.exports = {
    name: 'menu',
    category: 'General',
    emoji: '📜',
    async execute(m, { conn, plugins }) {
        const categories = {};

        for (const plugin of plugins) {
            const category = plugin.category || 'Others';
            const emoji = plugin.emoji || '❓';
            const label = `${emoji} ${plugin.name}`;

            if (!categories[category]) categories[category] = [];
            categories[category].push(label);
        }

        const menuText = buildMenu(categories);
        await conn.sendMessage(m.chat, { text: menuText }, { quoted: m });
    }
};