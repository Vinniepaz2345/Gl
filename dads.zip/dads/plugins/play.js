const { fetchJson } = require('../lib/myLib'); // Adjust based on your actual file structure

module.exports = {
  name: "play",
  alias: ["yt", "ytplay", "music", "grance"],
  category: "downloader", // Must match a valid menu category
  desc: "Download audio from YouTube using a keyword",
  async run({ conn, m, args, prefix, command }) {
    if (!args[0]) {
      return m.reply("✖️ What song do you want to play?");
    }

    try {
      const query = args.join(" ");
      let res = await fetchJson(`https://api.akuari.my.id/downloader/youtubeaudio?query=${encodeURIComponent(query)}`);
      
      if (!res || !res.result || !res.result.url) {
        return m.reply("✖️ Couldn't fetch audio. Try again.");
      }

      await conn.sendMessage(m.chat, {
        audio: { url: res.result.url },
        mimetype: 'audio/mpeg',
        fileName: `${res.result.title}.mp3`
      }, { quoted: m });

    } catch (e) {
      console.error(e);
      m.reply("✖️ Error fetching the audio.");
    }
  }
};