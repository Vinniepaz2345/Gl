const axios = require('axios');
const config = require('../config');

module.exports = {
  name: 'weather',
  aliases: ['forecast', 'temp'],
  category: 'utility',
  emoji: '☁️',
  async execute(m, context) {
    const location = (context && context.text ? context.text : '').trim();

    if (!location) {
      return m.reply('Please provide a location. Example: `.weather Nairobi`');
    }

    try {
      const apiKey = 'bcacd34d14337d5f57d51efa819a260e'; // Replace with your API key
      const response = await axios.get(`https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(location)}&appid=${apiKey}&units=metric`);
      const data = response.data;

      const weatherReport = `
┌─〔 ${config.botName} Weather 〕
│ Location: ${data.name}, ${data.sys.country}
│ Condition: ${data.weather[0].description}
│ Temp: ${data.main.temp}°C
│ Feels like: ${data.main.feels_like}°C
│ Humidity: ${data.main.humidity}%
│ Wind: ${data.wind.speed} m/s
└───────
© 2025 ${config.botName}
      `.trim();

      await m.reply(weatherReport);
    } catch (error) {
      console.error(error);
      m.reply('Failed to fetch weather info. Make sure the location is valid.');
    }
  },
};