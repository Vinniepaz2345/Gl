import axios from "axios";
import ytSearch from "yt-search";

let handler = async (m, { conn, text }) => {
  if (!text) return m.reply("❌ What song or video do you want to fetch?");

  await m.reply("🔄 *Vinnie MD bot is fetching your video... Please wait...*");

  try {
    let search = await ytSearch(text);
    let video = search.videos[0];

    if (!video) return m.reply("❌ No results found. Please refine your search.");

    let link = video.url;
    let apis = [
      `https://apis.davidcyriltech.my.id/youtube/mp4?url=${link}`,
      `https://api.ryzendesu.vip/api/downloader/ytmp4?url=${link}`
    ];

    for (const api of apis) {
      try {
        let { data } = await axios.get(api);

        if (data.status === 200 || data.success) {
          let videoUrl = data.result?.downloadUrl || data.url;
          let meta = {
            title: data.result?.title || video.title,
            author: data.result?.author || video.author.name,
            thumbnail: data.result?.image || video.thumbnail
          };

          await conn.sendMessage(
            m.chat,
            {
              image: { url: meta.thumbnail },
              caption: `Vinnie MD Bot
╭──────────────────
│ 🎬 *Title:* ${meta.title}
│ 👤 *Channel:* ${meta.author}
│ 🔗 *URL hidden for privacy*
╰──────────────────
*Powered by Vinnie MD*`
            },
            { quoted: m }
          );

          await m.reply("📤 *Sending your video file...*");

          await conn.sendMessage(
            m.chat,
            {
              video: { url: videoUrl },
              caption: `${meta.title}`,
              mimetype: "video/mp4"
            },
            { quoted: m }
          );

          await m.reply("✅ *Vinnie MD – Your video has been delivered successfully!*");
          return;
        }
      } catch (e) {
        console.error(`API Error (${api}):`, e.message);
        continue;
      }
    }

    return m.reply("⚠️ All APIs failed. Please try again later.");
  } catch (error) {
    return m.reply("❌ Video download failed\n" + error.message);
  }
};

handler.help = ["video"];
handler.tags = ["downloader"];
handler.command = /^video[\s✧♥]*$/i;

export default handler;