const fetch = require('node-fetch');

let handler = async (m, { text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(`Use like this:\n${usedPrefix + command} what is the capital of France?`);
  }

  try {
    // Try primary API
    const primary = await fetch(`https://api.kenzieapi.xyz/gpt?text=${encodeURIComponent(text)}`);
    const primaryJson = await primary.json();
    
    if (primary.ok && primaryJson && primaryJson.result) {
      return m.reply(primaryJson.result.trim());
    }

    // Fallback to secondary API
    const secondary = await fetch(`https://vihangayt.me/tools/chatgpt?q=${encodeURIComponent(text)}`);
    const secondaryJson = await secondary.json();
    
    if (secondary.ok && secondaryJson && secondaryJson.data) {
      return m.reply(secondaryJson.data.trim());
    }

    throw new Error('Both APIs failed');
  } catch (err) {
    console.error(err);
    return m.reply('Sorry, I could not get a response right now. Try again later.');
  }
};

handler.help = ['chatgpt'];
handler.tags = ['ai']; // optional if your system uses it
handler.command = ['chatgpt', 'gpt', 'ai', 'bro']; // aliases
handler.category = 'AI';
handler.emoji = '🤖'; // used by menu builder
handler.register = true;

module.exports = handler;