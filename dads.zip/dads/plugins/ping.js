module.exports = {
    name: 'ping',
    category: 'Utility',
    emoji: '🏓',
    async execute(m, { conn }) {
        await conn.sendMessage(m.chat, { text: 'Pong!' }, { quoted: m });
    }
};