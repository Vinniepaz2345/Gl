module.exports = {
  BOT_NAME: 'VinnieBot',
  FOOTER: '© 2025 VinnieBot'
};