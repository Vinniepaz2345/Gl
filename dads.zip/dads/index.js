const { default: makeWASocket, useMultiFileAuthState, DisconnectReason, makeInMemoryStore } = require('@whiskeysockets/baileys');
const { Boom } = require('@hapi/boom');
const P = require('pino');
const fs = require('fs');
const path = require('path');

const PREFIXES = ['.', '_', '/'];

const store = makeInMemoryStore({ logger: P().child({ level: 'silent', stream: 'store' }) });

async function startBot() {
    const { state, saveCreds } = await useMultiFileAuthState('session');

    const conn = makeWASocket({
        auth: state,
        printQRInTerminal: true,
        logger: P({ level: 'silent' }),
        browser: ['MyBot', 'Chrome', '1.0.0']
    });

    store.bind(conn.ev);
    conn.ev.on('creds.update', saveCreds);

    const plugins = loadPlugins();

    conn.ev.on('messages.upsert', async ({ messages }) => {
        const msg = messages[0];
        if (!msg?.message || msg.key?.remoteJid === 'status@broadcast') return;

        const m = serializeMessage(msg, conn);
        const body = m.body.trim();
        const cmdName = getCommandName(body);

        const plugin = plugins.find(p => p.name?.toLowerCase() === cmdName?.toLowerCase());
        if (plugin) {
            try {
                await plugin.execute(m, { conn, plugins });
            } catch (err) {
                console.error(`❌ Error in plugin "${plugin.name}":`, err);
                await conn.sendMessage(m.chat, { text: '⚠️ Error running command.' }, { quoted: m });
            }
        }
    });

    conn.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect } = update;
        if (connection === 'close') {
            const shouldReconnect = new Boom(lastDisconnect?.error)?.output?.statusCode !== DisconnectReason.loggedOut;
            console.log('Connection closed. Reconnecting...', shouldReconnect);
            if (shouldReconnect) startBot();
        }
    });

    console.log('✅ Bot is up and running...');
}

// Extract command name from message
function getCommandName(text) {
    if (!text) return '';
    for (let prefix of PREFIXES) {
        if (text.startsWith(prefix)) return text.slice(prefix.length).split(' ')[0];
    }
    return text.split(' ')[0]; // No prefix fallback
}

// Load all .js plugin files from /plugins
function loadPlugins() {
    const plugins = [];
    const pluginDir = path.join(__dirname, 'plugins');

    fs.readdirSync(pluginDir).forEach(file => {
        if (file.endsWith('.js')) {
            const plugin = require(path.join(pluginDir, file));
            if (plugin.name && typeof plugin.execute === 'function') {
                plugins.push(plugin);
            }
        }
    });

    return plugins;
}

// Extend message with reply and react
function serializeMessage(msg, conn) {
    const type = Object.keys(msg.message)[0];
    const body = msg.message[type]?.text || msg.message.conversation || '';
    const sender = msg.key.fromMe ? conn.user.id : msg.key.participant || msg.key.remoteJid;
    const chat = msg.key.remoteJid;

    return {
        ...msg,
        body,
        sender,
        chat,
        fromMe: msg.key.fromMe,
        reply: (text, options = {}) => conn.sendMessage(chat, { text, ...options }, { quoted: msg }),
        react: (emoji) => conn.sendMessage(chat, { react: { text: emoji, key: msg.key } }),
    };
}

startBot();